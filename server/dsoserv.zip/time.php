<?php
	echo time().'<end>';
?>